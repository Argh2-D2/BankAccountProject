﻿using System;
using System.IO;

namespace L7._5_ConsoleHeartsMiningGame
{
    class Program
    {
        static void Main(string[] args)
        {
            
            // initialise program variables
            char spade = '\u2660';
            char heart = '\u2665'; 
            int[] DifficultyLevel = { 1, 2, 3, 4, 5 };
            string DifficultyLevelEntered = "";
            string LetterSelected = "";
            bool CorrectLevelEntered = false;
            bool AllHeartsFound = false;
            int currentLevel = 0;
            int currentHeartsFound = 0;
            int currentSpadesFound = 0;
            bool fileSaved = false;
            decimal Score = 0;
            int totalHearts = 0;
            int totalSpades = 0;
            char[] AlphabetList = new char[] { 'A', 'B', 'C', 'D','E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X' };
            char[] isHeart = new char[] { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X' };
            String Table = "";
            int ColNo = 0;

            // change text encoding from ASCII to UTF8, to enable spade and hearts symboll display
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            
            //Enter your codes here
                while (CorrectLevelEntered == false)
            {

            Console.Write("Select Difficulty Level [1-5] inclusive.");
            DifficultyLevelEntered = Console.ReadLine();
                for (int i = 0; i < DifficultyLevel.Length; i++)
            {
                if (DifficultyLevelEntered == (DifficultyLevel[i].ToString()))
            {

            CorrectLevelEntered = true;
            currentLevel = DifficultyLevel[i];
                break;

            }
                else
            {

            }

            }

            }

                for (int j = 0; j < isHeart.Length; j++)
            {
            Random Rng = new Random();
                if (Rng.Next(0, currentLevel + 1) == 0)
            {
            isHeart[j] = heart;
            totalHearts++;
            }
                else
            {
            isHeart[j] = spade;
            totalSpades++;
            }
           
            }

            Console.WriteLine();

                for (int K = 0; K < AlphabetList.Length; K++)
            {
            Table = Table + "| " + AlphabetList[K] + " | ";
            ColNo++;

                if (ColNo == 6)
            {
            Console.WriteLine(Table);
            ColNo = 0;
            Table = "";
            }
                else
            {

            }

            }

            Console.WriteLine();
            Console.WriteLine("Hearts found: " + currentHeartsFound + " out of " + totalHearts.ToString());
            Console.WriteLine("Score: 0");

                while (AllHeartsFound == false)
            {
            Console.Write("Make a choice of alphabet from the grid display.");
            LetterSelected = Console.ReadLine();
                for (int i = 0; i < AlphabetList.Length; i++)
            {
                if (LetterSelected.ToUpper().EndsWith(AlphabetList[i].ToString()))
            {

            bool HeartFound = false;

            AlphabetList[i] = isHeart[i];

                if (AlphabetList[i] == heart)

            {
            
            currentHeartsFound++;
            HeartFound = true;

            }

                else

            {

            currentSpadesFound++;
           
            }


            Console.Clear();


            Console.WriteLine("Select Difficulty Level [1-5] inclusive." + currentLevel.ToString());
            
            Console.WriteLine();

                for (int K = 0; K < AlphabetList.Length; K++)
            {
            Table = Table + "| " + AlphabetList[K] + " | ";
            ColNo++;



                if (ColNo == 6)
            {
            Console.WriteLine(Table);
            ColNo = 0;
            Table = "";
            }
                else
            {



            }



            }


            Console.WriteLine();
                if (HeartFound == true)
            {
            Console.WriteLine("You've found a sweetheart.");
            }
                else
            {

            }

            Console.WriteLine("Hearts found: " + currentHeartsFound + " out of " + totalHearts.ToString());

            Console.WriteLine("Score: 0");

                if (currentHeartsFound == totalHearts)
            {
            AllHeartsFound = true;
            }
                else
            {

            }

            }
                else
            {


            }

            }


            }


            Console.Clear();
            Console.WriteLine("Select Difficulty Level [1-5] inclusive." + currentLevel.ToString());
            Console.WriteLine();

                for (int K = 0; K < AlphabetList.Length; K++)
            {
                Table = Table + "| " + AlphabetList[K] + " | ";
                ColNo++;

                if (ColNo == 6)
            {
            Console.WriteLine(Table);
            ColNo = 0;
            Table = "";
            }
                 else
            {

            }

            }

            Console.WriteLine();
            Console.WriteLine("Hearts found: " + currentHeartsFound + " out of " + totalHearts.ToString());

            decimal Attempts = Convert.ToDecimal(currentSpadesFound) + Convert.ToDecimal(currentHeartsFound);
            Score = (currentHeartsFound / Attempts) * 100;
            Score = Math.Round(Score);
            Console.WriteLine("Score: " + Score.ToString());

            System.IO.StreamWriter file = new System.IO.StreamWriter(@"C:\Users\Public\GameScore.txt", false);
            file.WriteLine("Score: " + Score.ToString());
            file.WriteLine("Difficulty: " + currentLevel.ToString());
            file.WriteLine("Number of Hearts: " + totalHearts.ToString());
            file.WriteLine("Number of Selections: " + Attempts.ToString());
            file.Close();
            fileSaved = true;

            Console.Write("Would you like to keep playing? (Y/N)");
            ConsoleKeyInfo ConsoleKey = Console.ReadKey();
                if (ConsoleKey.Key.ToString() == "y" || ConsoleKey.Key.ToString() == "Y")
            {
            Console.Write("\b \b");
            AllHeartsFound = false;
                while (AllHeartsFound == false)
            {

            int totalCount = Convert.ToInt32(totalHearts + totalSpades);

            Console.WriteLine();
            Console.WriteLine();
            Console.Write("Make a choice of alphabet from the grid display.");
            LetterSelected = Console.ReadLine();
                for (int i = 0; i < AlphabetList.Length; i++)
            {
                if (LetterSelected.ToUpper().EndsWith(AlphabetList[i].ToString()))
            {

            bool HeartFound = false;

            AlphabetList[i] = isHeart[i];

                if (AlphabetList[i] == heart)
            {
            currentHeartsFound++;
            HeartFound = true;
            }
                else
            {
            currentSpadesFound++;
            
            }

            Console.Clear();
            Console.WriteLine("Select Difficulty Level [1-5] inclusive." + currentLevel.ToString());
            Console.WriteLine();

                for (int K = 0; K < AlphabetList.Length; K++)
            {
            Table = Table + "| " + AlphabetList[K] + " | ";
            ColNo++;

                if (ColNo == 6)
            {
            Console.WriteLine(Table);
            ColNo = 0;
            Table = "";
            }
                else
            {


            }

            }

            Console.WriteLine();
                if (HeartFound == true)
            {
            Console.WriteLine("You've found a sweetheart.");
            }
                else
           
            {

            }

            Console.WriteLine("Hearts found: " + currentHeartsFound + " out of " + totalHearts.ToString());
            decimal Attempts2 = Convert.ToDecimal(currentSpadesFound) + Convert.ToDecimal(currentHeartsFound);
            Score = (currentHeartsFound / Attempts) * 100;
            Score = Math.Round(Score);
            Console.WriteLine("Score: " + Score.ToString());

                if (currentHeartsFound == totalHearts)
            {



                if (fileSaved == false)
            {
            file.WriteLine("Score: " + Score.ToString());
            file.WriteLine("Difficulty: " + currentLevel.ToString());
            file.WriteLine("Number of Hearts: " + totalHearts.ToString());
            file.WriteLine("Number of Selections: " + Attempts.ToString());
            file.Close();
            fileSaved = true;
            }
                else
            {


            }

            AllHeartsFound = true;
            }
                else
                {

            }
                 }
                else if (Convert.ToInt32(Attempts) == totalCount)
            {
                AllHeartsFound = true;
            }
                 else
                {

            }
                }

            }

             }
                else
                {
                Environment.Exit(0);
            }
                            

                    }
                }
            }
